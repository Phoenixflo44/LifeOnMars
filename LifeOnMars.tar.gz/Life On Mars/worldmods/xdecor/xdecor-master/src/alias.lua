minetest.register_alias("xdecor:crafting_guide", "craftguide:book")
