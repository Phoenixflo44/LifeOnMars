
-- This file intentionally left blank.

plantlife_i18n = { }

local MP = minetest.get_modpath(minetest.get_current_modname())
plantlife_i18n.gettext, plantlife_i18n.ngettext = dofile(MP.."/intllib.lua")
