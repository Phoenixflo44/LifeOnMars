vines.recipes['rope_block'] = {
  {'', 'group:wood', ''},
  {'', 'group:vines', ''},
  {'', 'group:vines', ''}
}

vines.recipes['shears'] = {
  {'', 'default:steel_ingot', ''},
  {'group:stick', 'group:wood', 'default:steel_ingot'},
  {'', '', 'group:stick'}
}
